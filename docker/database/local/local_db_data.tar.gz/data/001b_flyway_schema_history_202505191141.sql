INSERT INTO public.flyway_schema_history (installed_rank,"version",description,"type",script,checksum,installed_by,installed_on,execution_time,success) VALUES
	 (1,'000','<< Flyway Baseline >>','BASELINE','<< Flyway Baseline >>',NULL,'psqladmin','2024-03-21 12:13:23.709743',0,true),
	 (2,'001','CreateSchemaTables','SQL','V001__CreateSchemaTables.sql',-1802192326,'psqladmin','2024-03-21 12:25:01.19728',277,true),
	 (3,'002','CapitalizeEnums','SQL','V002__CapitalizeEnums.sql',-1769648521,'psqladmin','2024-03-21 12:25:01.544984',97,true),
	 (4,'003','ExtendCaptureSessionUrlLength','SQL','V003__ExtendCaptureSessionUrlLength.sql',-1280082212,'psqladmin','2024-03-21 12:25:01.700807',17,true),
	 (5,'004','RecordingDurationType','SQL','V004__RecordingDurationType.sql',-356889443,'psqladmin','2024-03-21 12:25:01.758509',19,true),
	 (6,'005','JoiningTablePKs','SQL','V005__JoiningTablePKs.sql',714807593,'psqladmin','2024-03-21 12:25:01.85585',113,true),
	 (7,'006','RenameShareRecordings','SQL','V006__RenameShareRecordings.sql',-1237291327,'psqladmin','2024-03-21 12:25:02.016979',34,true),
	 (8,'007','AuditCreatedByToUuid','SQL','V007__AuditCreatedByToUuid.sql',776861547,'psqladmin','2024-03-21 12:25:02.085338',26,true),
	 (9,'008','CreateInviteTable','SQL','V008__CreateInviteTable.sql',-1611819764,'psqladmin','2024-03-21 12:25:02.157502',22,true),
	 (10,'009','AddFieldRoles','SQL','V009__AddFieldRoles.sql',951902455,'psqladmin','2024-03-21 12:25:02.227776',34,true);
INSERT INTO public.flyway_schema_history (installed_rank,"version",description,"type",script,checksum,installed_by,installed_on,execution_time,success) VALUES
	 (11,'010','AmendConstraintsAndDroppingFields','SQL','V010__AmendConstraintsAndDroppingFields.sql',785850255,'psqladmin','2024-03-21 12:25:02.293686',12,true),
	 (12,'011','RemoveConstraintOnField','SQL','V011__RemoveConstraintOnField.sql',-522674421,'psqladmin','2024-03-21 12:25:02.338123',43,true),
	 (13,'012','UpdateAuditSchema','SQL','V012__UpdateAuditSchema.sql',-1661332536,'psqladmin','2024-03-21 12:25:02.411921',20,true),
	 (14,'013','ConsistentPortalAccessColumns','SQL','V013__ConsistentPortalAccessColumns.sql',-101498618,'psqladmin','2024-03-21 12:25:02.457378',34,true),
	 (15,'014','UpdateRecordingStatusType','SQL','V014__UpdateRecordingStatusType.sql',-418604979,'psqladmin','2024-03-21 12:25:02.516053',10,true),
	 (16,'015','UpdateFieldLength','SQL','V015__UpdateFieldLength.sql',132041987,'psqladmin','2024-03-21 12:25:02.556504',16,true),
	 (17,'016','RemoveInviteTableAndAddInviteCodeToPortalAccess','SQL','V016__RemoveInviteTableAndAddInviteCodeToPortalAccess.sql',1140557348,'psqladmin','2024-03-21 12:25:02.596544',7,true),
	 (18,'017','RemovePortalAccessPasswordField','SQL','V017__RemovePortalAccessPasswordField.sql',275266736,'psqladmin','2024-03-21 12:25:02.62956',6,true),
	 (19,'018','RemovePortalAccessInviteCode','SQL','V018__RemovePortalAccessInviteCode.sql',923734230,'psqladmin','2024-03-21 12:25:02.659949',6,true),
	 (20,'019','AddDefaultCourtAppAccess','SQL','V019__AddDefaultCourtAppAccess.sql',-1334940838,'psqladmin','2024-05-28 11:29:38.552908',31,true);
INSERT INTO public.flyway_schema_history (installed_rank,"version",description,"type",script,checksum,installed_by,installed_on,execution_time,success) VALUES
	 (21,'020','RemoveRecordingUrl','SQL','V020__RemoveRecordingUrl.sql',-2065748065,'psqladmin','2024-07-08 09:31:03.729855',21,true),
	 (22,'021','TermsAndConditions','SQL','V021__TermsAndConditions.sql',333257549,'psqladmin','2024-09-06 16:04:06.464489',105,true),
	 (23,'022','AddStateToCaseTable','SQL','V022__AddStateToCaseTable.sql',-257555805,'psqladmin','2024-10-09 11:10:01.480931',75,true),
	 (24,'023','AddTermsAndConditionsCopy','SQL','V023__AddTermsAndConditionsCopy.sql',-1895090135,'psqladmin','2024-10-14 15:48:31.308378',18,true),
	 (25,'024','AddTermsAndConditionsCopy','SQL','V024__AddTermsAndConditionsCopy.sql',206448555,'psqladmin','2024-11-14 13:51:58.774578',16,true),
	 (26,'025','AddTermsAndConditionsMultiline','SQL','V025__AddTermsAndConditionsMultiline.sql',-1832921099,'psqladmin','2024-11-15 09:53:34.063104',19,true),
	 (27,'026','AddNewCourtsNRO','SQL','V026__AddNewCourtsNRO.sql',1157369615,'psqladmin','2025-01-20 14:15:57.09486',82611,true),
	 (28,'027','UpdateNewCourtsNRO','SQL','V027__UpdateNewCourtsNRO.sql',-1479384925,'psqladmin','2025-02-03 14:22:46.933672',785,true),
	 (29,'028','UpdateNewCourtsNRO','SQL','V028__UpdateNewCourtsNRO.sql',-613099554,'psqladmin','2025-03-03 14:52:35.266663',3767,true),
	 (30,'029','CaseOrigin','SQL','V029__CaseOrigin.sql',942436338,'psqladmin','2025-03-27 11:34:30.081708',45,true);
INSERT INTO public.flyway_schema_history (installed_rank,"version",description,"type",script,checksum,installed_by,installed_on,execution_time,success) VALUES
	 (31,'030','EditRequests','SQL','V030__EditRequests.sql',2102647854,'psqladmin','2025-04-09 11:16:40.338109',114,true),
	 (32,'0031','DropTableRolePermissions','SQL','V0031__DropTableRolePermissions.sql',1334882664,'psqladmin','2025-05-16 14:07:35.779215',23,true);
