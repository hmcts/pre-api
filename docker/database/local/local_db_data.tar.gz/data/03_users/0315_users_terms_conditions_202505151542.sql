INSERT INTO public.users_terms_conditions (id, user_id, terms_and_conditions_id, accepted_at) VALUES
('bd82c071-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'george.barnes@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387'),
('bd82c072-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'oliver.scott@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387'),
('bd82c073-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'komal.dabhi@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387'),
('bd82c074-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'alexander.sealey@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387'),
('bd82c075-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'ruth.bovell@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387'),
('bd82c076-e599-46b5-8e99-c943fc36e3f6'::uuid, (SELECT id FROM users where email = 'lydia.ralph@hmcts.net'), 'a017f73f-0ca7-4297-a249-d8e023f61800'::uuid, '2026-01-09 10:20:37.387')
ON CONFLICT DO NOTHING ;
