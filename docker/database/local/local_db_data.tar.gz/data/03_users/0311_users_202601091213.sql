INSERT INTO public.users (id, first_name, last_name, email, organisation, phone, deleted_at, created_at, modified_at, alternative_email) VALUES
  ('abcd0aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid, 'PRE', 'Dev', 'dts-pre-app-dev@hmcts.net', '', '', NULL, '2022-06-24 18:37:00.000', '2024-11-21 13:34:27.149', NULL),
  ('f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid, 'PRE', 'Admin', 'dts-pre-app-stg@hmcts.net', '', '', NULL, '2022-06-24 18:37:00.000', '2024-11-21 13:34:27.149', NULL),
  ('ab750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid, 'PRE', 'TestSuperUser', 'pretestsuperuser@HMCTS.NET', '', '', NULL, '2022-06-24 18:37:00.000', '2024-11-21 13:34:27.149', NULL),
  ('c56e379e-88cc-417c-801a-8647b82825c9'::uuid, 'Lydia', 'Ralph (DEV)', 'lydia.ralph@hmcts.net', '', '', NULL, '2025-01-10 10:47:33.364', '2025-11-05 09:04:32.678', NULL),
  ('2b4f1cbb-e3d4-405e-9d24-e21f75df8f1f'::uuid, 'George', 'Barnes', 'george.barnes@hmcts.net', '', '', NULL, '2025-01-10 10:49:54.325', '2025-02-21 17:08:22.671', NULL),
  ('8da77965-acec-4256-b695-509924a11f06'::uuid, 'Komal', 'Dabhi (DEV)', 'komal.dabhi@hmcts.net', '', '', NULL, '2025-06-17 12:46:31.126', '2025-07-15 10:04:16.811', NULL),
  ('6216ba11-2c89-46d7-8f5d-f9788d97c126'::uuid, 'Ruth', 'Bovell', 'ruth.bovell@hmcts.net', '', '', NULL, '2025-08-13 14:37:48.432', '2025-08-13 14:37:48.431', NULL),
  ('3eba7664-d7b7-4fd5-862e-a9c1d79e2f3d'::uuid, 'Oliver', 'Scott (Dev)', 'oliver.scott@hmcts.net', '', '', NULL, '2025-06-13 10:27:34.852', '2025-06-13 10:27:34.848', NULL),
  ('1e706a83-cf2a-4ad1-a81f-b6e0d0804f0f'::uuid, 'Alexander', 'Sealey (DEV)', 'alexander.sealey@hmcts.net', '', '', NULL, '2025-06-25 13:57:52.147', '2025-07-11 10:04:03.736', NULL)
ON CONFLICT DO NOTHING ;
