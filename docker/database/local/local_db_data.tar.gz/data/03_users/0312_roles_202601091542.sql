INSERT INTO public.roles (id,name,description) VALUES
	 ('e583d10b-eb59-48a8-8771-a1aff72877e3'::uuid,'Super User',NULL),
	 ('4e13f352-d78a-4b65-932c-f46464be6d38'::uuid,'Level 1','Admin Access through Teams'),
	 ('fd1f4509-2583-466d-b0b9-ff138d22541a'::uuid,'Level 2','Clerks, Court Associates, Ushers, Legal Advisors, JIT'),
	 ('95ebbcde-c27c-42d5-89f2-b0960350db5e'::uuid,'Level 3','External Access via Portal'),
	 ('8e1da9b5-fea7-4eea-b431-602821a89fe1'::uuid,'Level 4','Level 4')
ON CONFLICT DO NOTHING ;

