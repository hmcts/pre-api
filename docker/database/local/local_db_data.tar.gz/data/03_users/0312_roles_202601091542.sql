INSERT INTO public.roles (id, name, description)
SELECT v.id, v.name, v.description
FROM (
    VALUES
        ('4e13f352-d78a-4b65-932c-f46464be6d38'::uuid, 'Level 1', 'Admin Access through Teams'),
        ('fd1f4509-2583-466d-b0b9-ff138d22541a'::uuid, 'Level 2', 'Clerks, Court Associates, Ushers, Legal Advisors, JIT'),
        ('95ebbcde-c27c-42d5-89f2-b0960350db5e'::uuid, 'Level 3', 'External Access via Portal'),
        ('8e1da9b5-fea7-4eea-b431-602821a89fe1'::uuid, 'Level 4', 'Level 4')
) AS v(id, name, description)
WHERE NOT EXISTS (
    SELECT 1
    FROM public.roles r
    WHERE r.name = v.name
);