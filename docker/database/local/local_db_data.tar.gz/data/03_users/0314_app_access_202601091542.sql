INSERT INTO public.app_access (id, user_id, court_id, role_id, last_access, active, deleted_at, created_at, modified_at,
                               default_court) VALUES
  ('e8ba581f-9d20-489f-a71f-52f44d4b2b0b'::uuid,
        (SELECT id from users where email = 'dts-pre-app-stg@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Level 3'),
        '2024-07-11 17:34:48.491451+01', true, NULL, '2024-07-11 17:34:48.491451+01',
        '2024-07-11 17:34:48.486+01', true),

  ('abba581f-9d20-489f-a71f-52f44d4b2b0b'::uuid,
   (SELECT id from users where email = 'dts-pre-app-dev@hmcts.net'),
   (SELECT id from courts where "name" = '102 Petty France'),
   (SELECT id from roles where "name" = 'Level 3'),
   '2024-07-11 17:34:48.491451+01', true, NULL, '2024-07-11 17:34:48.491451+01',
   '2024-07-11 17:34:48.486+01', true),

       ('cc8c0521-bcd7-4b38-9bef-d6a63b14391c'::uuid,
        (SELECT id from users where email = 'george.barnes@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        NULL, false, NULL,
        '2024-03-21 15:11:12.75512+00', '2024-03-21 15:11:25.291+00', true),

       ('55b3013e-5b6c-4f96-b256-6b33f18f8881'::uuid,
        (SELECT id from users where email = 'lydia.ralph@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        NULL, true, NULL,
        '2023-11-13 15:21:16+00', '2024-03-21 15:05:01.097+00', true),

       ('b5d3ac51-c053-4d59-9d15-a6301f31ba96'::uuid,
        (SELECT id from users where email = 'komal.dabhi@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        NULL, true, NULL,
        '2024-03-21 17:59:49.838599+00', '2024-03-21 17:59:49.837+00', true),

       ('b70c00db-2a30-45b1-b436-60b428f08182'::uuid,
        (SELECT id from users where email = 'ruth.bovell@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        NULL, true, NULL,
        '2024-07-02 18:15:40.910642+01', '2024-07-02 18:15:40.908+01', true),

       ('7470b773-b305-426e-9adf-50d71c791655'::uuid,
        (SELECT id from users where email = 'oliver.scott@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        NULL, true, NULL,
        '2024-06-26 15:04:43.807118+01', '2024-06-26 16:33:57.105+01', true),

       ('1cab8e24-5529-4f45-929c-8fddcf6334f5'::uuid,
        (SELECT id from users where email = 'alexander.sealey@hmcts.net'),
        (SELECT id from courts where "name" = '102 Petty France'),
        (SELECT id from roles where "name" = 'Super User'),
        '2024-06-27 15:06:30.023023+01', true, NULL, '2024-06-27 15:05:59.680835+01', '2024-06-27 15:06:30.025+01',
        true),

  ('abab8e24-5529-4f45-929c-8fddcf6334f5'::uuid,
    (SELECT id from users where email = 'pretestsuperuser@HMCTS.NET'),
    (SELECT id from courts where "name" = '102 Petty France'),
    (SELECT id from roles where "name" = 'Super User'),
    '2024-06-27 15:06:30.023023+01', true, NULL, '2024-06-27 15:05:59.680835+01', '2024-06-27 15:06:30.025+01',
    true)

ON CONFLICT DO NOTHING ;


