INSERT INTO public.regions (id,name) VALUES
	 ('6e43a141-226b-4a1c-bd2b-6f92979e5f5b'::uuid,'London'),
	 ('12efa09a-f02a-4e66-a465-a72e22fca191'::uuid,'West Midlands (England)'),
	 ('5c044c4f-7821-4eaa-95a2-d4d9a72560cd'::uuid,'East Midlands (England)'),
	 ('afd9b552-c052-4da6-9041-6c405cc24c15'::uuid,'Yorkshire and The Humber'),
	 ('b461a86d-2fe1-4e1a-aa26-0066b1ba96c6'::uuid,'North East (England)'),
	 ('57516238-9b4d-4b4f-a449-bbe8bd8ac96e'::uuid,'North West (England)'),
	 ('0583d77f-8bd5-46c5-94f1-fd189fd03dff'::uuid,'South East (England)'),
	 ('df9433c4-4d42-48e6-bc31-8640499c45a0'::uuid,'East of England'),
	 ('58ed2389-eb47-4381-8093-5b94563abba0'::uuid,'South West (England)')
ON CONFLICT DO NOTHING ;
INSERT INTO public.regions (id,name) VALUES
	 ('1c2d1a44-4935-4ad8-9cfe-f3e6f5d0e17a'::uuid,'Wales'),
	 ('63842b01-d27f-405e-beac-ad1365bcb1dd'::uuid,'Test'),
	 ('6413b2e4-964c-4471-b80c-95ff880e799a'::uuid,'Default')
ON CONFLICT DO NOTHING ;
