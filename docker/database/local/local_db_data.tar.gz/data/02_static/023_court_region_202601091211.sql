INSERT INTO public.court_region (court_id,region_id) VALUES
	 ('e04200fc-67e0-457d-99af-6ce27b2cbab1'::uuid,'6e43a141-226b-4a1c-bd2b-6f92979e5f5b'::uuid),
	 ('d0822b6c-8474-48d6-acec-1ed211041f05'::uuid,'6e43a141-226b-4a1c-bd2b-6f92979e5f5b'::uuid),
	 ('8fb4599b-9670-4256-b0b0-5722f49a1888'::uuid,'6e43a141-226b-4a1c-bd2b-6f92979e5f5b'::uuid)
ON CONFLICT DO NOTHING ;
