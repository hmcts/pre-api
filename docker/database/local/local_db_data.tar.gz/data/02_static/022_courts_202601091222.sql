INSERT INTO public.courts (id,"court_type","name",location_code,county,postcode) VALUES
	 ('e04200fc-67e0-457d-99af-6ce27b2cbab1'::uuid,'CROWN'::public."court_type",'102 Petty France','',NULL,NULL),
	 ('d0822b6c-8474-48d6-acec-1ed211041f05'::uuid,'CROWN'::public."court_type",'Isle of Wight Combined Court','478',NULL,NULL),
	 ('8fb4599b-9670-4256-b0b0-5722f49a1888'::uuid,'CROWN'::public."court_type",'Preston Combined Court','448',NULL,NULL)
ON CONFLICT DO NOTHING ;
