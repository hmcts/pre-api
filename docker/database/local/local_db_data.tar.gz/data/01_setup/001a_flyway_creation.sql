CREATE TABLE IF NOT EXISTS public.flyway_schema_history (
  installed_rank INT,
  "version"      varchar(50),
  description    VARCHAR(200),
  "type"         VARCHAR(20),
  script         VARCHAR(1000),
  checksum       INT,
  installed_by   VARCHAR(100),
  installed_on   TIMESTAMP,
  execution_time INT,
  success        BOOLEAN
);
