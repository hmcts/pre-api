INSERT INTO public.share_bookings (id,booking_id,shared_with_user_id,shared_by_user_id,created_at,deleted_at) VALUES
	 ('a5cee7ac-b40e-404c-8601-67dd0dfcbb68'::uuid,'aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,
	  (SELECT id from users where email = 'lydia.ralph@hmcts.net'),
	  'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 10:55:00+00',NULL),

	 ('8b7a0116-bd21-4bcb-b5ad-e43d574e8e32'::uuid,'aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,(SELECT id from users where email = 'george.barnes@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 12:01:00+00',NULL),
	 ('458570da-9207-400b-9dc6-ef316eba2070'::uuid,'aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,(SELECT id from users where email = 'komal.dabhi@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 14:11:00+00',NULL),
	 ('49e9446d-4d52-4b44-9d87-652ef2b7f734'::uuid,'aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,(SELECT id from users where email = 'ruth.bovell@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 15:45:00+00',NULL),
	 ('ffb770f6-ae6a-404f-83a3-2b84429d6ece'::uuid,'c6471538-4892-4776-9258-b777edb57644'::uuid,(SELECT id from users where email = 'komal.dabhi@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 15:48:00+00',NULL),
	 ('1fe28aec-fdad-4a76-8b1f-dedfffa24d1c'::uuid,'c6471538-4892-4776-9258-b777edb57644'::uuid,(SELECT id from users where email = 'oliver.scott@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-09 13:15:00+00',NULL),
	 ('1f57a5d1-5d74-4a0b-946d-63746b966100'::uuid,'c6471538-4892-4776-9258-b777edb57644'::uuid,(SELECT id from users where email = 'alexander.sealey@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-09 13:22:00+00',NULL),
	 ('0c7edf7c-efe9-4ec2-a3cd-6b855969ac28'::uuid,'c6471538-4892-4776-9258-b777edb57644'::uuid,(SELECT id from users where email = 'george.barnes@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-09 09:43:00+00',NULL),
	 ('d26b5155-e9d7-46f5-8b81-99c96276feb8'::uuid,'09284d16-2de1-4bc9-951a-d98f5caecdf4'::uuid,(SELECT id from users where email = 'komal.dabhi@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-09 14:49:00+00',NULL),
	 ('37906d0e-b01c-452f-80f7-b9ad654f2369'::uuid,'09284d16-2de1-4bc9-951a-d98f5caecdf4'::uuid,(SELECT id from users where email = 'lydia.ralph@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 10:03:00+00',NULL),
	 ('1095daef-9e25-4d84-84dd-bde095d3c55f'::uuid,'09284d16-2de1-4bc9-951a-d98f5caecdf4'::uuid,(SELECT id from users where email = 'ruth.bovell@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 11:54:00+00',NULL),
	 ('ce94451c-8938-40ef-bd4c-61efc24b47fd'::uuid,'727c7a3b-9c07-453e-b6bd-a367eea79412'::uuid,(SELECT id from users where email = 'komal.dabhi@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 12:30:00+00',NULL),
	 ('1b644d5e-cfdd-4b29-8ba9-65c4d35202b7'::uuid,'727c7a3b-9c07-453e-b6bd-a367eea79412'::uuid,(SELECT id from users where email = 'alexander.sealey@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 12:34:00+00',NULL),
	 ('00832883-6ed6-4832-8eab-bfb8e96ee1a6'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'oliver.scott@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 13:05:00+00',NULL),
	 ('618d0a86-7fcc-48bc-adc5-0c810822ed33'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'komal.dabhi@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 13:19:00+00',NULL),
	 ('28d7532b-b655-4be5-ac35-605c9dd1a744'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'lydia.ralph@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-08 10:56:00+00',NULL),
	 ('2c25b759-1e05-4367-b870-2d0614448353'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'alexander.sealey@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 14:27:00+00',NULL),
	 ('2fcb0b37-9acc-4066-8215-166b011154b6'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'ruth.bovell@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 14:09:00+00',NULL),
	 ('bdadaa1c-2d78-40ff-bc0d-a3f69765c52b'::uuid,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from users where email = 'george.barnes@hmcts.net'),'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,'2023-03-10 14:24:00+00',NULL)
ON CONFLICT DO NOTHING ;
