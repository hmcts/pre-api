INSERT INTO public.booking_participant (id,booking_id, participant_id) VALUES
-- TEST-1
	 (1,'aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,'b71a793a-744d-4710-a9a3-7172202b9090'::uuid),
	 (2,'c6471538-4892-4776-9258-b777edb57644'::uuid,'a2d617a5-89cc-4dc9-b1a4-decc3195110e'::uuid),

-- TEST-2
	 (3,'09284d16-2de1-4bc9-951a-d98f5caecdf4'::uuid,'5101f7a2-34e6-4d9f-b546-811c09366033'::uuid),

-- TEST-3
	 (4,'727c7a3b-9c07-453e-b6bd-a367eea79412'::uuid,'7399baf8-9c7c-471c-83d0-d3d9949c656d'::uuid),

-- TEST-4
	 (5,'27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,'689fb28e-f3c4-4133-bd23-7cb0646b3c20'::uuid),

-- TEST-5
	 (6,'b9aa7b55-ee57-4434-ada7-4288f3b6e8f9'::uuid,'179d9059-aa8d-ed11-81ad-00224841b000'::uuid),
	 (7,'7f7bce58-1db1-4c26-a8d3-485108eb141b'::uuid,'6c955893-ad8d-ed11-81ad-00224841b000'::uuid),
	 (8,'7f7bce58-1db1-4c26-a8d3-485108eb141b'::uuid,'712bae55-b08d-ed11-81ad-00224841b000'::uuid),

-- TEST-6
	 (9,'8b4b0956-6f27-420d-9c67-93c0b3975f1f'::uuid,'2e9f015b-cc8d-ed11-81ad-00224841b000'::uuid),
	 (10,'68508c2d-e9c6-4f11-a897-c98bab7279aa'::uuid,'2e9f015b-cc8d-ed11-81ad-00224841b000'::uuid)
ON CONFLICT DO NOTHING ;
