INSERT INTO public.edit_requests (id, source_recording_id, edit_instruction, status, started_at, finished_at, created_by, created_at, modified_at, jointly_agreed, rejection_reason, approved_at, approved_by)
VALUES('11669ede-3c6c-4fcc-a266-7220afc26b87'::uuid, '8ac163d9-865d-4a1c-8db8-c8ebc0a3874c'::uuid,
       '{"ffmpegInstructions": [{"end": 50, "start": 0}], "requestedInstructions": [{"end": 54, "start": 50, "reason": "Removing last 4 seconds", "end_of_cut": "00:00:54", "start_of_cut": "00:00:50"}]}'::json,
       'SUBMITTED'::public."edit_request_status",
       '2025-12-12 17:00:40.712', NULL,
       'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,
       '2025-12-12 16:59:46.783', '2025-12-12 17:00:40.737',
       NULL, NULL, NULL, NULL);

INSERT INTO public.edit_requests (id, source_recording_id, edit_instruction, status, started_at, finished_at, created_by, created_at, modified_at, jointly_agreed, rejection_reason, approved_at, approved_by)
VALUES('6d271c7f-e25f-43e4-b97b-5a16c6253776'::uuid,
       '225ecd38-c830-4664-bfbc-038289f681f3'::uuid,
       '{"ffmpegInstructions": [{"end": 10, "start": 0}, {"end": 54, "start": 20}], "requestedInstructions": [{"end": 20, "start": 10, "reason": "test", "end_of_cut": "00:00:20", "start_of_cut": "00:00:10"}]}'::json,
       'DRAFT'::public."edit_request_status",
       NULL,
       NULL,
       'f8750aa0-ecf3-ec11-bb3c-0022481b1f95'::uuid,
       '2026-01-20 09:29:09.594', '2026-01-20 09:29:17.970',
       NULL, NULL, NULL, NULL);
