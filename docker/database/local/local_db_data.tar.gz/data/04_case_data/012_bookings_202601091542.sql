INSERT INTO public.bookings (id,case_id,scheduled_for,deleted_at,created_at,modified_at) VALUES
	 ('aeda5190-557b-401b-b7a7-647f0cea8d06'::uuid,(SELECT id from cases where reference = 'TEST-1'),'2024-07-03 16:24:27.15075+01',NULL,'2024-06-26 16:24:27.16+01','2024-06-26 16:24:27.164+01'),
	 ('c6471538-4892-4776-9258-b777edb57644'::uuid,(SELECT id from cases where reference = 'TEST-1'),'2024-07-03 16:24:28.438155+01','2024-06-26 16:24:29.018294+01','2024-06-26 16:24:28.444+01','2024-06-26 16:24:28.446+01'),
	 ('09284d16-2de1-4bc9-951a-d98f5caecdf4'::uuid,(SELECT id from cases where reference = 'TEST-2'),'2023-06-17 00:00:00+01',NULL,'2023-06-16 17:17:00+01','2023-06-16 17:20:00+01'),
	 ('727c7a3b-9c07-453e-b6bd-a367eea79412'::uuid,(SELECT id from cases where reference = 'TEST-3'),'2023-09-29 00:00:00+01',NULL,'2023-09-28 17:12:00+01','2023-09-28 17:12:00+01'),
	 ('27a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from cases where reference = 'TEST-4'),'2024-07-03 16:24:29.371018+01',NULL,'2024-06-26 16:24:29.379956+01','2024-06-26 16:24:29.402+01'),
	 ('37a141e2-6d5b-4a3b-b41f-81146e7e9f04'::uuid,(SELECT id from cases where reference = 'TEST-4'),'2023-06-12 00:00:00+01',NULL,'2023-06-09 16:09:00+01','2023-06-09 16:09:00+01'),
	 ('b9aa7b55-ee57-4434-ada7-4288f3b6e8f9'::uuid,(SELECT id from cases where reference = 'TEST-5'),'2023-11-20 00:00:00+00',NULL,'2023-11-20 16:29:00+00','2023-11-20 16:29:00+00'),
	 ('7f7bce58-1db1-4c26-a8d3-485108eb141b'::uuid,(SELECT id from cases where reference = 'TEST-5'),'2023-06-16 00:00:00+01',NULL,'2023-06-16 16:15:00+01','2023-06-16 16:19:00+01'),
	 ('8b4b0956-6f27-420d-9c67-93c0b3975f1f'::uuid,(SELECT id from cases where reference = 'TEST-6'),'2023-06-16 00:00:00+01',NULL,'2023-06-16 16:17:00+01','2023-06-16 16:17:00+01'),
	 ('68508c2d-e9c6-4f11-a897-c98bab7279aa'::uuid,(SELECT id from cases where reference = 'TEST-6'),'2023-07-04 00:00:00+01',NULL,'2023-07-04 11:33:00+01','2023-07-04 11:33:00+01')
ON CONFLICT DO NOTHING ;
