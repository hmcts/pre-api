INSERT INTO public.participants (id,case_id,participant_type,first_name,last_name,deleted_at,created_at,modified_at) VALUES
	 ('f680c442-5196-4ee4-aca3-027b2bfc1414'::uuid,(SELECT id FROM cases where reference = 'TEST-1'),'DEFENDANT'::public.participant_type,'Jane','Doe',NULL,'2024-06-26 16:24:27.142587+01','2024-06-26 16:24:27.134+01'),
	 ('b71a793a-744d-4710-a9a3-7172202b9090'::uuid,(SELECT id FROM cases where reference = 'TEST-1'),'WITNESS'::public.participant_type,'John','Smith',NULL,'2024-06-26 16:24:27.137814+01','2024-06-26 16:24:27.128+01'),
	 ('a2d617a5-89cc-4dc9-b1a4-decc3195110e'::uuid,(SELECT id FROM cases where reference = 'TEST-1'),'WITNESS'::public.participant_type,'Example','Person',NULL,'2024-06-26 16:24:28.107734+01','2024-06-26 16:24:28.094+01'),

	 ('84a7a1d2-2f9e-4fa8-909c-1c9e4cdb4344'::uuid, (SELECT id FROM cases where reference = 'TEST-2'),'DEFENDANT'::public.participant_type,'Example','Person',NULL,'2024-06-26 16:24:28.11064+01','2024-06-26 16:24:28.101+01'),
	 ('5101f7a2-34e6-4d9f-b546-811c09366033'::uuid,(SELECT id FROM cases where reference = 'TEST-2'),'WITNESS'::public.participant_type,'John','Smith',NULL,'2024-06-26 16:24:28.427237+01','2024-06-26 16:24:28.42+01'),

	 ('640b43bd-f1f9-4180-bddb-34c377bc1d55'::uuid,(SELECT id FROM cases where reference = 'TEST-3'),'DEFENDANT'::public.participant_type,'Jane','Doe',NULL,'2024-06-26 16:24:28.430475+01','2024-06-26 16:24:28.424+01'),
	 ('7399baf8-9c7c-471c-83d0-d3d9949c656d'::uuid,(SELECT id FROM cases where reference = 'TEST-3'),'WITNESS'::public.participant_type,'John','Smith',NULL,'2024-06-26 16:24:29.359585+01','2024-06-26 16:24:29.353+01'),

	 ('274e5900-5482-4a2a-bf95-423d9087bae6'::uuid,(SELECT id FROM cases where reference = 'TEST-4'),'DEFENDANT'::public.participant_type,'Jane','Doe',NULL,'2024-06-26 16:24:29.362594+01','2024-06-26 16:24:29.357+01'),
	 ('689fb28e-f3c4-4133-bd23-7cb0646b3c20'::uuid,(SELECT id FROM cases where reference = 'TEST-4'),'WITNESS'::public.participant_type,'Paul','Pump',NULL,'2024-03-21 12:56:16.199091+00','2024-03-21 12:56:16.19+00'),

	 ('d2c7a269-b2c1-46ce-98fa-f773a3dfca19'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'DEFENDANT'::public.participant_type,'Tim','Trump',NULL,'2024-03-21 12:56:16.202794+00','2024-03-21 12:56:16.194+00'),
	 ('179d9059-aa8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit1','wit1',NULL,'2023-01-06 10:10:00+00','2023-01-06 10:10:00+00'),
	 ('6c955893-ad8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit1','wit1',NULL,'2023-01-06 10:33:00+00','2023-01-06 10:33:00+00'),
	 ('712bae55-b08d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'witness','witness',NULL,'2023-01-06 10:53:00+00','2023-01-06 10:53:00+00'),
	 ('2141b854-cc8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit2','wit2',NULL,'2023-01-06 14:13:00+00','2023-01-06 14:13:00+00'),
	 ('279f015b-cc8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit5','wit5',NULL,'2023-01-06 14:13:00+00','2023-01-06 14:14:00+00'),
	 ('2b9f015b-cc8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit7','wit7',NULL,'2023-01-06 14:13:00+00','2023-01-06 14:14:00+00'),
	 ('349f015b-cc8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-5'),'WITNESS'::public.participant_type,'wit12','wit12',NULL,'2023-01-06 14:14:00+00','2023-01-06 14:14:00+00'),

	 ('51530e15-ab8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-6'),'DEFENDANT'::public.participant_type,'def','1',NULL,'2023-01-06 10:15:00+00','2023-03-10 11:42:00+00'),
	 ('2e9f015b-cc8d-ed11-81ad-00224841b000'::uuid,(SELECT id FROM cases where reference = 'TEST-6'),'WITNESS'::public.participant_type,'wit8','wit8',NULL,'2023-01-06 14:13:00+00','2023-01-06 14:14:00+00')
ON CONFLICT DO NOTHING ;
